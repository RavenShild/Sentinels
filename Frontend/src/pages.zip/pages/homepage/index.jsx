import React from "react";
import '../../css/geral.css';
import { CardCivis, CardMilitares, CardOutrasOm, CardRelatorio } from "../../components/card";
import Navbar from "../../components/navbar";
import { jwtDecode } from "jwt-decode";
import Footer from "../../components/footer";


export default function HomePage() {
    const token = localStorage.getItem('token');
    let isAdmin = false;

    if (token) {
        // Decodificar o token para acessar as informações
        const decodedToken = jwtDecode(token);

        // Verificar se o token indica que o usuário é administrador
        isAdmin = decodedToken && decodedToken.isAdmin === 1; // 'role' é apenas um exemplo, você deve usar a chave correta no token
    }

    
    const decodedToken = jwtDecode(token);
    
    //console.log(token);
    //console.log(decodedToken.isAdmin);
    //console.log(isAdmin);

    return <>
        <Navbar />
        <div className="container mt-2">
            <h1 className="text-center">Relações da Guarda</h1>
            <hr />
            <h3>Civis</h3>
            <div className="d-flex mt-2">
                <CardCivis link="/civis" titulo="Registro" />

            </div>
            <hr />
            <h3>Militares do QG</h3>
            <div className="d-flex mt-2">
                <CardMilitares link="/durante_expediente" titulo="Durante o expediente" />
                <CardMilitares link="/fora_expediente" titulo="Após o expediente" />
 
            </div>
            <hr />
            <h3>Outras Organizações Militares</h3>
            <div className="d-flex mt-2">
                <CardOutrasOm link="/outra_om_durante_expediente" titulo="Durante o expediente" />
                <CardOutrasOm link="/outra_om_fora_expediente" titulo="Fora de expediente" />

            </div>
            <hr />
            <h3>Relatório</h3>
            <div className="d-flex mt-2 mb-5">
                {isAdmin && (
                    <>
                        <CardRelatorio link="/relatorio_armazenar_servico" titulo="Finalizar Serviço" />
                        <CardRelatorio link="/cadastroMil" titulo="Cadastrar Militares" />
                        <CardRelatorio link="/cadastroUser" titulo="Cadastrar Usuários" />
                    </>
                )}
                <CardRelatorio link="/relatorio_servico_anterior" titulo="Consultar serviços anteriores" />
            </div>

        </div>
        <Footer />
    </>
}